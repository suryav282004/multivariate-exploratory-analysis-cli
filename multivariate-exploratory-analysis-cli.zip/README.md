# Multivariate Exploratory Analysis and Dimensionality Reduction CLI

A Python command-line tool that performs multivariate exploratory data analysis (EDA), Mahalanobis-distance outlier screening, and Principal Component Analysis (PCA) on CSV datasets.

## Features

- CSV dataset loading
- Numeric feature selection
- Missing/infinite value handling (median imputation)
- Descriptive statistics and correlation matrix
- Correlation heatmap and feature histograms
- Standardization using `StandardScaler`
- Mahalanobis distance and statistical outlier candidate screening
- PCA transformation, explained-variance report, loading matrix, scree plot, and PC1-PC2 visualization
- Execution log saved to `outputs/execution_log.txt`

## Requirements

Python 3.9+ recommended.

Install dependencies:

```bash
pip install -r requirements.txt
```

## Run

```bash
python src/main.py --input data/dataset.csv --output outputs
```

Optional confidence level for Mahalanobis screening:

```bash
python src/main.py --input data/dataset.csv --output outputs --alpha 0.975
```

## Output files

- `descriptive_statistics.csv`
- `correlation_matrix.csv`
- `missing_values.csv`
- `correlation_heatmap.png`
- `histograms.png`
- `mahalanobis_results.csv`
- `mahalanobis_plot.png`
- `pca_transformed_data.csv`
- `pca_variance_report.csv`
- `pca_loadings.csv`
- `pca_scree_plot.png`
- `pca_2d.png`
- `summary.csv`
- `execution_log.txt`

## Method

1. Read the CSV.
2. Select numeric columns.
3. Replace infinite values and impute missing values with column medians.
4. Remove constant features.
5. Produce exploratory statistics and plots.
6. Standardize numeric features.
7. Calculate Mahalanobis distance and flag candidate outliers using a chi-square threshold.
8. Perform PCA and export component scores, explained variance, and loadings.

**Note:** Mahalanobis outlier flags are statistical candidates, not automatic proof of data errors. The chi-square interpretation relies on distributional assumptions and can be affected by small samples, collinearity, and non-normal data.

## Git and DVC workflow

```bash
git init
dvc init
dvc add data/dataset.csv
git add src README.md requirements.txt .gitignore .dvcignore data/dataset.csv.dvc
git commit -m "Initial multivariate analysis CLI"
```

Track code in Git and data through DVC. To make data reproducible across machines, configure and push to a DVC remote.

## Verification

Run the CLI, inspect the generated files under `outputs/`, and preserve the actual execution log. Do not submit fabricated output or metrics.

## License

For academic use. Add a license if publishing for broader reuse.
