import argparse
import os
import sys
import logging

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from scipy.spatial.distance import mahalanobis
from scipy.stats import chi2
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


def setup_logging(output_dir):
    os.makedirs(output_dir, exist_ok=True)
    log_path = os.path.join(output_dir, "execution_log.txt")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(log_path, mode="w", encoding="utf-8"),
            logging.StreamHandler(sys.stdout)
        ],
        force=True
    )
    logging.info("Starting Multivariate Exploratory Analysis CLI")


def load_dataset(path):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Dataset file not found: {path}")
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError("The dataset is empty.")
    logging.info("Dataset loaded: %s rows x %s columns", df.shape[0], df.shape[1])
    logging.info("Columns: %s", list(df.columns))
    return df


def select_numeric_and_clean(df, output_dir):
    numeric = df.select_dtypes(include=np.number).copy()
    if numeric.shape[1] < 2:
        raise ValueError("Dataset must contain at least two numeric columns.")

    # Replace infinite values and impute missing values with column median.
    numeric = numeric.replace([np.inf, -np.inf], np.nan)
    missing_counts = numeric.isna().sum()
    missing_counts.to_csv(os.path.join(output_dir, "missing_values.csv"), header=["Missing_Count"])

    numeric = numeric.fillna(numeric.median())
    numeric = numeric.loc[:, numeric.nunique() > 1]

    if numeric.shape[1] < 2:
        raise ValueError("After cleaning, at least two non-constant numeric columns are required.")

    logging.info("Selected %s numeric features after cleaning", numeric.shape[1])
    return numeric


def run_eda(data, output_dir):
    logging.info("Running exploratory data analysis")
    data.describe().T.to_csv(os.path.join(output_dir, "descriptive_statistics.csv"))
    data.corr().to_csv(os.path.join(output_dir, "correlation_matrix.csv"))

    plt.figure(figsize=(10, 7))
    sns.heatmap(data.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
    plt.title("Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "correlation_heatmap.png"), dpi=150)
    plt.close()

    data.hist(figsize=(12, 8), bins=20)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "histograms.png"), dpi=150)
    plt.close()
    logging.info("EDA reports and plots saved")


def scale_features(data):
    scaler = StandardScaler()
    scaled = scaler.fit_transform(data)
    logging.info("Features standardized using StandardScaler")
    return scaled, scaler


def run_mahalanobis(scaled, output_dir, alpha=0.975):
    logging.info("Calculating Mahalanobis distances")
    mean_vector = np.mean(scaled, axis=0)
    covariance = np.cov(scaled, rowvar=False)
    inverse_covariance = np.linalg.pinv(covariance)

    distances = np.array([
        mahalanobis(row, mean_vector, inverse_covariance)
        for row in scaled
    ])

    # Squared Mahalanobis distances follow approximately chi-square distribution
    # under multivariate normal assumptions. Compare squared distance to threshold.
    threshold_squared = chi2.ppf(alpha, df=scaled.shape[1])
    flagged = distances ** 2 > threshold_squared

    result = pd.DataFrame({
        "Mahalanobis_Distance": distances,
        "Squared_Distance": distances ** 2,
        "Outlier_Candidate": flagged
    })
    result.to_csv(os.path.join(output_dir, "mahalanobis_results.csv"), index=False)

    plt.figure(figsize=(10, 5))
    plt.scatter(np.arange(len(distances)), distances, s=20)
    plt.axhline(np.sqrt(threshold_squared), linestyle="--", label=f"Threshold ({alpha:.1%})")
    plt.xlabel("Observation Index")
    plt.ylabel("Mahalanobis Distance")
    plt.title("Mahalanobis Distance Outlier Screening")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "mahalanobis_plot.png"), dpi=150)
    plt.close()

    logging.info("Threshold: %.4f; outlier candidates: %d", np.sqrt(threshold_squared), int(flagged.sum()))
    return result


def run_pca(scaled, feature_names, output_dir):
    logging.info("Running PCA")
    pca_full = PCA()
    transformed = pca_full.fit_transform(scaled)

    components = [f"PC{i+1}" for i in range(transformed.shape[1])]
    pca_df = pd.DataFrame(transformed, columns=components)
    pca_df.to_csv(os.path.join(output_dir, "pca_transformed_data.csv"), index=False)

    variance_df = pd.DataFrame({
        "Principal_Component": components,
        "Explained_Variance_Ratio": pca_full.explained_variance_ratio_,
        "Cumulative_Explained_Variance": np.cumsum(pca_full.explained_variance_ratio_)
    })
    variance_df.to_csv(os.path.join(output_dir, "pca_variance_report.csv"), index=False)

    loadings = pd.DataFrame(
        pca_full.components_.T,
        index=feature_names,
        columns=components
    )
    loadings.to_csv(os.path.join(output_dir, "pca_loadings.csv"))

    # Scree plot
    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(1, len(components)+1), pca_full.explained_variance_ratio_, marker="o")
    plt.xlabel("Principal Component")
    plt.ylabel("Explained Variance Ratio")
    plt.title("PCA Scree Plot")
    plt.xticks(np.arange(1, len(components)+1))
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "pca_scree_plot.png"), dpi=150)
    plt.close()

    # PC1 vs PC2 plot
    if transformed.shape[1] >= 2:
        plt.figure(figsize=(8, 6))
        plt.scatter(transformed[:, 0], transformed[:, 1], s=25)
        plt.xlabel("PC1")
        plt.ylabel("PC2")
        plt.title("PCA Projection: PC1 vs PC2")
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "pca_2d.png"), dpi=150)
        plt.close()

    logging.info("PCA completed; first two components explain %.2f%% of variance",
                 100 * np.sum(pca_full.explained_variance_ratio_[:2]))
    return pca_df, variance_df, loadings


def main():
    parser = argparse.ArgumentParser(
        description="Multivariate EDA, Mahalanobis distance and PCA CLI"
    )
    parser.add_argument("--input", required=True, help="Path to input CSV dataset")
    parser.add_argument("--output", default="outputs", help="Output directory (default: outputs)")
    parser.add_argument("--alpha", type=float, default=0.975,
                       help="Chi-square confidence level for outlier screening (default: 0.975)")
    args = parser.parse_args()

    if not 0.5 < args.alpha < 1:
        parser.error("--alpha must be between 0.5 and 1")

    setup_logging(args.output)
    try:
        df = load_dataset(args.input)
        numeric = select_numeric_and_clean(df, args.output)
        run_eda(numeric, args.output)
        scaled, _ = scale_features(numeric)
        outlier_results = run_mahalanobis(scaled, args.output, alpha=args.alpha)
        pca_df, variance_df, loadings = run_pca(scaled, numeric.columns.tolist(), args.output)

        summary = {
            "rows_processed": len(numeric),
            "features_processed": numeric.shape[1],
            "outlier_candidates": int(outlier_results["Outlier_Candidate"].sum()),
            "variance_first_two_components": float(variance_df["Explained_Variance_Ratio"].iloc[:2].sum())
        }
        pd.Series(summary, name="Value").to_csv(os.path.join(args.output, "summary.csv"))
        logging.info("Summary: %s", summary)
        logging.info("SUCCESS: All analyses completed. Outputs saved in %s", args.output)
    except Exception as exc:
        logging.exception("FAILED: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
